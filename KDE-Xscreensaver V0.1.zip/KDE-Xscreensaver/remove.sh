#!/bin/bash
#This script will remove xscreensaver integration fom KDE

##################################################################
#              Developed by sergio melas 2021                    #
##################################################################


echo  "Login as sudo to remove"
sudo ls >/dev/null
echo  ""
echo  "Removing system configuration files"
VAR=$0
DIR="$(dirname "${VAR}")"
cd  "${DIR}"

#remove packages
sudo apt-get remove xscreensaver xscreensaver-data-extra xscreensaver-gl-extra xfishtank
sudo apt-get autoremove

#Remove Xscrensaver service from systemd
systemctl --user disable xscreensaver
rm  ~/.config/systemd/user/xscreensaver.service
sudo systemctl daemon-reload

#Restore Standard config
sudo apt-get reinstall libkscreenlocker*
sudo apt-get reinstall kde-config-screenlocker*

sudo rm /usr/lib/x86_64-linux-gnu/libexec/kscreenlocker_greet.bkp
sudo rm /usr/share/kpackage/kcms/kcm_screenlocker/contents/ui/main.qml.bkp

#Remove scripts
sudo rm -r /usr/KDE_xscreesaver








