#!/bin/bash
#This script will install autorotate system for KDE

echo  " "
echo  " ##################################################################"
echo  " #           xscreensaver integration in kde plasma               #"
echo  " #         Developed for KDE Plasma  by sergio melas 2022         #"
echo  " #                                                                #"
echo  " #                Emai: sergiomelas@gmail.com                     #"
echo  " #                   Released unde GPV V3.0                       #"
echo  " #                                                                #"
echo  " ##################################################################"
echo  " "



VAR=$0
DIR="$(dirname "${VAR}")"
cd  "${DIR}"

echo  "Login as sudo to install"
sudo ls >/dev/null
echo  ""

#Install Stuff
echo  "Creating system configuration files"
sudo apt-get install xscreensaver xscreensaver-data-extra xscreensaver-gl-extra xfishtank
cp ./Payload/xscreensaver.service ~/.config/systemd/user/
chmod 644 ~/.config/systemd/user/xscreensaver.service
systemctl --user enable xscreensaver
sudo systemctl daemon-reload

#Substitute kcm_screenlocker with xscreensaver
echo replacing kscreenlocker with Xscreensaver
if [ ! -e /usr/lib/x86_64-linux-gnu/libexec/kscreenlocker_greet.bkp ]; then
  sudo cp /usr/lib/x86_64-linux-gnu/libexec/kscreenlocker_greet /usr/lib/x86_64-linux-gnu/libexec/kscreenlocker_greet.bkp
fi
sudo cp ./Payload/kscreenlocker_greet /usr/lib/x86_64-linux-gnu/libexec/

#Update setting interface
if [ ! -e /usr/lib/x86_64-linux-gnu/libexec/kscreenlocker_greet.bkp ]; then
  sudo cp /usr/share/kpackage/kcms/kcm_screenlocker/contents/ui/main.qml /usr/share/kpackage/kcms/kcm_screenlocker/contents/ui/main.qml.bkp
fi
sudo cp ./Payload/main.qml /usr/share/kpackage/kcms/kcm_screenlocker/contents/ui/







