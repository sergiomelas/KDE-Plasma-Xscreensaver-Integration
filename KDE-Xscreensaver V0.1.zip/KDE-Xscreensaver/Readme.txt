                     ##################################################################
                     ##################################################################
                     ###                   Xscreensaver for KDE                     ###
                     ### Developed by sergio melas (sergiomelas@gmail.com) 2021-22  ###
                     ##################################################################
                     ##################################################################

Installation Instructions:
  -Unzip the file
  -drag and drop  install.sh script in a terminal
  -reboot
  -Configure Xscresaver running xscreesaver-demo (Kde menu/Setting/Screensaver) do not activate locking (see next):
       Put black screen to 720 (to deactivate autostart)
  -Configure  KDE screenlocking  (System setting/Screen Locking to configure Xscreensaver locking)


Removal Instructions:

  -To unistall run remove.sh

Note: this software works only for Kde Plasma

##################################################################################################################
Change log:

V0.1: -Initial version with integration with KDE plasma 5
